package com.example.nelson.petagram.email;

/**
 * Created by Belal on 10/30/2015.
 */
public class Config {
    public static final String EMAIL ="usuario@correo.com";
    public static final String PASSWORD ="claveusuario";
}